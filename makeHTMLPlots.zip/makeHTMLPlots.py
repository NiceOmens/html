#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Generate plots viewable in browsers
"""

import pandas as pd
import math
import matplotlib.pyplot as plt

# import table

table = pd.read_csv('table.csv')
table['index'] = list(table.index)
filename = 'png/test.png'

fig = plt.figure(figsize=[8,6],dpi=100)
ax = plt.gca()

# generate plots on figure
table.plot('X','Y0',ax=plt.gca(),rot=90) # more efficient to use line instead of scatter
table.plot('X','Y0',ax=plt.gca(),rot=90)

# get pixel coordinates for plotted points
# https://sodocumentation.net/matplotlib/topic/4566/coordinates-systems
# https://matplotlib.org/stable/tutorials/advanced/transforms_tutorial.html
fig_size = fig.get_size_inches()*fig.dpi # width, height of image in pixels
np_a = table[['index','Y0']].to_numpy() # if the graphed x-column is categorical, use index instead of the x-column
xy_pixels = ax.transData.transform(np_a)
xpix, ypix = xy_pixels.T

# save image to file
plt.savefig(filename,format='png')

# next step is to have a hover window when the mouse is inside a section of the window
# use the xpix to create a width and left corner for each x-axis value which are used to define event boundaries
# Note: using title blocks due to automatic hover events

nl = '&#013;' # newline in html title
html = open('viewer.html','w') # start of of html file
html.write('<!DOCTYPE html><html>\n') # html file header info

# First image in html file
html.write('<body><img usemap="#' +filename.replace('.png','1')+ '" src="' +filename +'">\n') #start body, link img, indicate mapping will be used
html.write('<map name="'+filename.replace('.png','1')+'">\n') # give a name to the map

# honestly, html doesn't really break due to subpixel titles
if abs(xpix[0]-xpix[1])<1:
    inc = math.ceil(1/abs(xpix[1]-xpix[0]))
    
else:
    inc = 1
diff = abs(xpix[0]-xpix[1])*inc
for i in range(0,len(xpix),inc):
    title = 'Y1: '+str(table['Y1'][i])+nl+\
            'Y2: '+str(table['Y2'][i])+nl+\
            'Y3: '+str(table['Y3'][i])+nl+\
            'Y4: '+str(table['Y4'][i])+nl+\
            'Y0: '+str(table['Y0'][i])+nl+"figure 1;"
    html.write('<area shape="rect" href="" coords="'+str(xpix[i])+','+str(int(fig_size[1]))+','+str(xpix[i]+diff)+',0'+'" title="'+title+'">')
html.write('</map></body>\n') # end of map & body

# Second image in html file
html.write('<body><img usemap="#' +filename.replace('.png','2')+ '" src="' +filename +'">\n') #start body, link img, indicate mapping will be used
html.write('<map name="'+filename.replace('.png','2')+'">\n') # give a name to the map

# honestly, html doesn't really break due to subpixel titles
if abs(xpix[0]-xpix[1])<1:
    inc = math.ceil(1/abs(xpix[1]-xpix[0]))
    
else:
    inc = 1
diff = abs(xpix[0]-xpix[1])*inc
for i in range(0,len(xpix),inc):
    title = 'Y1: '+str(table['Y1'][i])+nl+\
            'Y2: '+str(table['Y2'][i])+nl+\
            'Y3: '+str(table['Y3'][i])+nl+\
            'Y4: '+str(table['Y4'][i])+nl+\
            'Y0: '+str(table['Y0'][i])+nl+"figure 2;"
    html.write('<area shape="rect" href="" coords="'+str(xpix[i])+','+str(int(fig_size[1]))+','+str(xpix[i]+diff)+',0'+'" title="'+title+'">')
html.write('</map></body>\n') # end of map & body


html.write('</html>\n') # end of html file
html.close()